// ============================================================
//  TELA, TOQUES E DESENHO
//  Aqui ficam o hangar, os botões, a câmera e o visual do foguete.
// ============================================================
(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };
  var cvs = $('cv'), ctx = cvs.getContext('2d');
  var W = 0, H = 0, DPR = 1;

  function resize() {
    DPR = Math.min(window.devicePixelRatio || 1, 2);
    W = window.innerWidth; H = window.innerHeight;
    cvs.width = Math.round(W * DPR); cvs.height = Math.round(H * DPR);
    cvs.style.width = W + 'px'; cvs.style.height = H + 'px';
  }
  window.addEventListener('resize', resize);
  resize();

  // ---------- cores do foguete ----------
  var COL = {
    capsule: '#e9eef9', window: '#6fd3ff', tank: '#f2f4fa', stripe: '#ff7a45',
    engine: '#59607a', mini: '#b6f24a', miniFin: '#4a8a1f', flame: '#ff7a45', flameCore: '#ffd37a'
  };

  // ---------- configuração salva ----------
  var KEY = 'orbitaLivre.cfg.v1';
  function loadCfg() {
    try {
      var s = JSON.parse(localStorage.getItem(KEY));
      if (s && s.tank && s.engine) return { tank: s.tank, tanks: s.tanks || 2, engine: s.engine, minis: s.minis == null ? 1 : s.minis };
    } catch (e) {}
    return JSON.parse(JSON.stringify(DEFAULT_CONFIG));
  }
  function saveCfg() { try { localStorage.setItem(KEY, JSON.stringify(cfg)); } catch (e) {} }

  var cfg = loadCfg();
  var sim = new Sim(cfg);
  var screen = 'hangar';
  var view = { map: false, zoom: 10, mapZoom: 1, warp: 1 };
  var WARPS = [1, 4, 16, 64];
  var held = { left: false, right: false };
  var thr = 0;
  var trail = [], trailT = 0;
  var boomParts = null;

  var stars = [];
  for (var si = 0; si < 120; si++) stars.push({ x: Math.random(), y: Math.random(), r: Math.random() * 1.2 + 0.3 });

  // ---------- utilidades de desenho ----------
  function mix(a, b, t) {
    t = clamp(t, 0, 1);
    return 'rgb(' + Math.round(a[0] + (b[0] - a[0]) * t) + ',' + Math.round(a[1] + (b[1] - a[1]) * t) + ',' + Math.round(a[2] + (b[2] - a[2]) * t) + ')';
  }
  function tri(c, x1, y1, x2, y2, x3, y3) {
    c.beginPath(); c.moveTo(x1, y1); c.lineTo(x2, y2); c.lineTo(x3, y3); c.closePath(); c.fill();
  }
  function fmtDist(m) {
    if (!isFinite(m)) return '—';
    var a = Math.abs(m);
    if (a >= 10000) return (m / 1000).toFixed(1) + ' km';
    return Math.round(m) + ' m';
  }

  function drawStars(alpha) {
    if (alpha <= 0.02) return;
    ctx.fillStyle = 'rgba(255,255,255,' + alpha.toFixed(2) + ')';
    for (var i = 0; i < stars.length; i++) {
      var s = stars[i];
      ctx.fillRect(s.x * W, s.y * H, s.r, s.r);
    }
  }

  // ---------- foguete (desenhado em metros, nariz para cima, origem no centro) ----------
  function drawRocket(c, rk, flame, vac) {
    var cp = PARTS.capsule, tk = rk.tank, en = rk.eng, mn = PARTS.mini;
    var i, b, y, L;
    var bottom = rk.H / 2;

    if (flame > 0) {
      L = (2.5 + 9 * flame) * (0.75 + 0.45 * vac) * (0.85 + 0.3 * Math.random());
      var fw = en.w * 0.55 * (0.9 + 0.5 * vac);
      c.fillStyle = COL.flame; tri(c, -fw, bottom - 0.2, fw, bottom - 0.2, 0, bottom + L);
      c.fillStyle = COL.flameCore; tri(c, -fw * 0.5, bottom - 0.2, fw * 0.5, bottom - 0.2, 0, bottom + L * 0.6);
    }

    for (i = 0; i < rk.boosters.length; i++) {
      b = rk.boosters[i];
      if (!b.alive) continue;
      var bx = b.cx, bt = bottom - 0.4 - mn.h, sg = Math.sign(bx);
      c.strokeStyle = COL.engine; c.lineWidth = 0.18;
      c.beginPath(); c.moveTo(bx, bt + mn.h * 0.35); c.lineTo(sg * rk.W / 2 * 0.9, bt + mn.h * 0.35); c.stroke();
      if (b.firing) {
        L = 1.8 + 1.6 * Math.random();
        c.fillStyle = COL.flame; tri(c, bx - mn.w * 0.4, bt + mn.h, bx + mn.w * 0.4, bt + mn.h, bx, bt + mn.h + L);
        c.fillStyle = COL.flameCore; tri(c, bx - mn.w * 0.2, bt + mn.h, bx + mn.w * 0.2, bt + mn.h, bx, bt + mn.h + L * 0.55);
      }
      c.fillStyle = COL.mini; c.fillRect(bx - mn.w / 2, bt + 0.7, mn.w, mn.h - 0.7);
      c.fillStyle = COL.stripe; tri(c, bx - mn.w / 2, bt + 0.7, bx + mn.w / 2, bt + 0.7, bx, bt);
      c.fillStyle = COL.miniFin; tri(c, bx, bt + mn.h - 1, bx + sg * 0.55, bt + mn.h, bx, bt + mn.h);
    }

    y = -rk.H / 2;
    c.fillStyle = COL.capsule;
    c.beginPath();
    c.moveTo(0, y);
    c.quadraticCurveTo(cp.w / 2, y + cp.h * 0.35, cp.w / 2, y + cp.h);
    c.lineTo(-cp.w / 2, y + cp.h);
    c.quadraticCurveTo(-cp.w / 2, y + cp.h * 0.35, 0, y);
    c.closePath(); c.fill();
    c.fillStyle = COL.window; c.beginPath(); c.arc(0, y + cp.h * 0.62, cp.w * 0.2, 0, Math.PI * 2); c.fill();
    y += cp.h;

    for (i = 0; i < rk.n; i++) {
      c.fillStyle = COL.tank; c.fillRect(-tk.w / 2, y, tk.w, tk.h);
      c.fillStyle = COL.stripe; c.fillRect(-tk.w / 2, y + tk.h * 0.4, tk.w, tk.h * 0.12);
      c.fillStyle = 'rgba(20,30,70,0.18)'; c.fillRect(tk.w * 0.22, y, tk.w * 0.28, tk.h);
      y += tk.h;
    }

    c.fillStyle = COL.stripe;
    tri(c, -tk.w / 2, y - 1.2, -tk.w / 2 - 0.6, y + en.h, -tk.w / 2, y + en.h * 0.8);
    tri(c, tk.w / 2, y - 1.2, tk.w / 2 + 0.6, y + en.h, tk.w / 2, y + en.h * 0.8);
    c.fillStyle = COL.engine;
    c.beginPath();
    c.moveTo(-en.w * 0.3, y); c.lineTo(en.w * 0.3, y); c.lineTo(en.w * 0.5, y + en.h); c.lineTo(-en.w * 0.5, y + en.h);
    c.closePath(); c.fill();
  }

  // ---------- HANGAR ----------
  function chip(act, val, label, on, cls) {
    return '<button class="chip ' + (cls || '') + (on ? ' on' : '') + '" data-act="' + act + '" data-val="' + val + '">' + label + '</button>';
  }
  function stepper(key, val, suffix) {
    return '<button class="step" data-act="' + key + '-">−</button><span class="val">' + val + (suffix || '') + '</span><button class="step" data-act="' + key + '+">+</button>';
  }
  function renderHangar() {
    var h = '';
    h += '<div class="row"><label>Tanque</label>' + PARTS.tanks.map(function (t) {
      return chip('tank', t.id, t.name.replace('Tanque ', ''), cfg.tank === t.id);
    }).join('') + '</div>';
    h += '<div class="row"><label>Quantidade</label>' + stepper('tanks', cfg.tanks) + '</div>';
    h += '<div class="row"><label>Motor</label>' + PARTS.engines.map(function (e) {
      return chip('engine', e.id, e.name, cfg.engine === e.id);
    }).join('') + '</div>';
    h += '<div class="row"><label>Mini foguetes<br>automáticos</label>' + stepper('minis', cfg.minis * 2, '') + '<span class="val" style="color:var(--dim);font-size:12px">' + (cfg.minis ? cfg.minis + (cfg.minis > 1 ? ' pares' : ' par') : 'nenhum') + '</span></div>';
    $('hangarRows').innerHTML = h;

    var rk = buildRocket(cfg), mn = PARTS.mini;
    var nb = rk.boosters.length;
    var m0 = rk.dry + rk.fuelMax + nb * (mn.dry + mn.fuel);
    var thrust = rk.eng.thrust * 0.82 + nb * mn.thrust;
    var twr = thrust / (m0 * G0);
    var ve = rk.eng.isp * G0;
    var mMain = rk.dry + rk.fuelMax;
    var dv = ve * Math.log(mMain / rk.dry);
    if (nb) dv += mn.isp * G0 * Math.log(m0 / (m0 - nb * mn.fuel * 0.6));
    var okDv = dv >= 4300, okTwr = twr >= 1.3;
    $('hangarStats').innerHTML =
      '<div><b>MASSA</b><i>' + (m0 / 1000).toFixed(1) + ' t</i></div>' +
      '<div class="' + (okTwr ? 'ok' : 'low') + '"><b>EMPUXO/PESO</b><i>' + twr.toFixed(2) + '</i></div>' +
      '<div class="' + (okDv ? 'ok' : 'low') + '"><b>ΔV</b><i>' + Math.round(dv) + ' m/s</i></div>';
  }

  $('hangarRows').addEventListener('click', function (e) {
    var el = e.target.closest('[data-act]');
    if (!el) return;
    var act = el.getAttribute('data-act'), val = el.getAttribute('data-val');
    if (act === 'tank') cfg.tank = val;
    else if (act === 'engine') cfg.engine = val;
    else if (act === 'tanks-') cfg.tanks = clamp(cfg.tanks - 1, 1, 4);
    else if (act === 'tanks+') cfg.tanks = clamp(cfg.tanks + 1, 1, 4);
    else if (act === 'minis-') cfg.minis = clamp(cfg.minis - 1, 0, 3);
    else if (act === 'minis+') cfg.minis = clamp(cfg.minis + 1, 0, 3);
    saveCfg();
    renderHangar();
  });

  function drawHangar() {
    var top = $('hangar').getBoundingClientRect().top;
    var g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, '#05081a'); g.addColorStop(1, '#1b2a55');
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    drawStars(0.9);
    var rk = buildRocket(cfg);
    var maxW = rk.W + 2 * (rk.pairs ? (rk.W / 2 + PARTS.mini.w + rk.pairs * 0.9) : 0);
    var sc = Math.min((top - 70) / (rk.H + 4), (W * 0.8) / Math.max(maxW, 6));
    sc = Math.max(sc, 4);
    var cx = W / 2, groundY = top - 24;
    var cy = groundY - rk.H / 2 * sc;
    ctx.fillStyle = '#26345f'; ctx.fillRect(0, groundY, W, H - groundY);
    ctx.fillStyle = '#3a4c85'; ctx.fillRect(cx - rk.W * sc * 1.2, groundY, rk.W * sc * 2.4, 6);
    ctx.save();
    ctx.translate(cx, cy); ctx.scale(sc, sc);
    drawRocket(ctx, rk, 0, 0);
    ctx.restore();
  }

  // ---------- VOO ----------
  function startFlight() {
    sim = new Sim(cfg);
    thr = 0; held.left = held.right = false;
    view.map = false; view.mapZoom = 1; view.warp = 1;
    view.zoom = clamp(0.22 * H / sim.rocket.H, 3, 30);
    trail = []; trailT = 0; boomParts = null;
    screen = 'flight';
    $('hangar').hidden = true; $('flight').hidden = false; $('over').hidden = true;
    syncButtons();
  }
  function toHangar() {
    screen = 'hangar';
    $('flight').hidden = true; $('hangar').hidden = false;
    renderHangar();
  }

  function effectiveWarp() {
    var eff = view.warp, s = sim;
    if (eff > 1) {
      var firing = false;
      for (var i = 0; i < s.rocket.boosters.length; i++) if (s.rocket.boosters[i].firing) firing = true;
      if (s.state !== 'flying' || s.throttle > 0 || thr > 0 || s.alt < PLANET.atmHeight || firing) eff = 1;
      else if (s.auto && s.phase !== 'ORBITA') eff = Math.min(eff, 4);
    }
    return eff;
  }

  function stepPhysics(rdt) {
    sim.thrIn = thr;
    sim.rotIn = (held.left ? 1 : 0) - (held.right ? 1 : 0);
    var eff = effectiveWarp();
    var simDt = rdt * eff;
    var n = Math.max(1, Math.ceil(simDt / 0.04)), h = simDt / n;
    for (var i = 0; i < n; i++) sim.step(h);
    trailT += simDt;
    if (trailT > 1 && sim.state === 'flying') {
      trailT = 0;
      trail.push(sim.x, sim.y);
      if (trail.length > 1600) trail.splice(0, 2);
    }
    if (sim.state === 'crashed' && !boomParts) {
      boomParts = [];
      for (var k = 0; k < 40; k++) boomParts.push({ a: Math.random() * Math.PI * 2, s: 30 + Math.random() * 140, r: 2 + Math.random() * 5, c: Math.random() < 0.5 ? COL.flame : COL.flameCore });
      $('overTitle').textContent = 'Colisão!';
      $('overText').textContent = 'O foguete bateu forte demais. Para pousar, chegue devagar (menos de 14 m/s) com o nariz para cima.';
      $('over').hidden = false;
    }
  }

  function skyAt(alt) {
    var t = clamp(alt / 55000, 0, 1);
    return { top: mix([40, 96, 150], [4, 5, 14], t + 0.25), bottom: mix([112, 176, 214], [4, 5, 14], t - 0.05), t: t };
  }

  function drawFlight() {
    var s = sim, rk = s.rocket, sc = view.zoom;
    var rho = clamp(s.alt / PLANET.atmHeight, 0, 1);
    var sky = skyAt(s.alt);
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    var g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, sky.top); g.addColorStop(1, sky.bottom);
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    drawStars(clamp((s.alt - 12000) / 40000, 0, 1));

    // chão: o planeta é um círculo enorme; desenha só o pedaço visível
    var Rs = PLANET.radius * sc;
    var pcy = H / 2 + s.r * sc;
    ctx.fillStyle = '#2c6b52';
    ctx.beginPath();
    if (Rs > 4 * Math.max(W, H)) {
      ctx.moveTo(-20, H + 40);
      for (var x = -20; x <= W + 20; x += 10) {
        var dx = x - W / 2;
        ctx.lineTo(x, pcy - Math.sqrt(Rs * Rs - dx * dx));
      }
      ctx.lineTo(W + 20, H + 40);
      ctx.closePath();
    } else {
      ctx.arc(W / 2, pcy, Rs, 0, Math.PI * 2);
    }
    ctx.fill();
    ctx.strokeStyle = 'rgba(160,230,255,' + (0.55 - 0.45 * sky.t).toFixed(2) + ')';
    ctx.lineWidth = 3; ctx.stroke();

    // marcas no chão a cada tantos metros (dão sensação de velocidade)
    var phiR = Math.atan2(s.y, s.x);
    var spacing = 100;
    while (spacing * sc < 70) spacing *= 5;
    var dphi = spacing / PLANET.radius;
    var k0 = Math.round((Math.PI / 2 - phiR) / dphi);
    var span = Math.ceil((W / sc) / spacing) + 2;
    ctx.strokeStyle = 'rgba(10,40,30,0.45)'; ctx.lineWidth = 2;
    for (var kk = k0 - span; kk <= k0 + span; kk++) {
      var d = kk * dphi;
      var sx = W / 2 - Rs * Math.sin(d), sy = pcy - Rs * Math.cos(d);
      if (sx < -20 || sx > W + 20 || Math.abs(d) > 1.5) continue;
      ctx.save(); ctx.translate(sx, sy); ctx.rotate(-d);
      ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, 10); ctx.stroke();
      ctx.restore();
    }

    // base de lançamento
    var dPad = Math.PI / 2 - phiR;
    if (Math.abs(dPad * PLANET.radius * sc) < W) {
      var px = W / 2 - Rs * Math.sin(dPad), py = pcy - Rs * Math.cos(dPad);
      ctx.save(); ctx.translate(px, py); ctx.rotate(-dPad); ctx.scale(sc, sc);
      ctx.fillStyle = '#8190b8'; ctx.fillRect(-4, -0.6, 8, 0.6);
      ctx.fillStyle = '#566187'; ctx.fillRect(-6, 0, 12, 0.3);
      ctx.fillStyle = '#ff7a45'; ctx.fillRect(4.5, -9, 0.5, 9);
      ctx.fillRect(3.2, -9, 1.8, 0.4);
      ctx.restore();
    }

    var rho2 = Math.PI / 2 - s.upAng, cr = Math.cos(rho2), sr = Math.sin(rho2);

    // pedaços soltos
    for (var i = 0; i < s.debris.length; i++) {
      var db = s.debris[i];
      var ddx = db.x - s.x, ddy = db.y - s.y;
      var ex = W / 2 + sc * (ddx * cr - ddy * sr), ey = H / 2 - sc * (ddx * sr + ddy * cr);
      if (ex < -50 || ex > W + 50 || ey < -50 || ey > H + 50) continue;
      ctx.save(); ctx.translate(ex, ey); ctx.rotate(Math.PI / 2 - db.th - rho2); ctx.scale(sc, sc);
      ctx.fillStyle = COL.mini; ctx.fillRect(-PARTS.mini.w / 2, -PARTS.mini.h / 2, PARTS.mini.w, PARTS.mini.h);
      ctx.fillStyle = COL.stripe; tri(ctx, -PARTS.mini.w / 2, -PARTS.mini.h / 2, PARTS.mini.w / 2, -PARTS.mini.h / 2, 0, -PARTS.mini.h / 2 - 0.7);
      ctx.restore();
    }

    if (s.state !== 'crashed') {
      var srk = Math.max(sc, 14 / rk.H);
      ctx.save();
      ctx.translate(W / 2, H / 2);
      ctx.rotate(Math.PI / 2 - s.th - rho2);
      ctx.scale(srk, srk);
      drawRocket(ctx, rk, s.fuel > 0 ? s.throttle : 0, 1 - Math.exp(-s.alt / PLANET.scaleHeight));
      ctx.restore();
    } else if (s.boom && boomParts) {
      var t = s.boom.t;
      for (var q = 0; q < boomParts.length; q++) {
        var p = boomParts[q], dist = p.s * t * (1 - Math.min(t, 2.5) / 3.5);
        ctx.globalAlpha = clamp(1 - t / 2.2, 0, 1);
        ctx.fillStyle = p.c;
        ctx.beginPath(); ctx.arc(W / 2 + Math.cos(p.a) * dist, H / 2 - Math.sin(p.a) * dist, p.r * (1 - t / 3), 0, Math.PI * 2); ctx.fill();
      }
      ctx.globalAlpha = 1;
    }
  }

  function drawMap() {
    var s = sim, o = s.orb, R = PLANET.radius;
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    ctx.fillStyle = '#05061a'; ctx.fillRect(0, 0, W, H);
    drawStars(1);
    var rView = Math.max(R * 1.6, isFinite(o.ra) ? o.ra * 1.12 : s.r * 1.5, s.r * 1.15) / view.mapZoom;
    var ms = Math.min(W, H) * 0.42 / rView;
    var cx = W / 2, cy = H / 2;

    ctx.fillStyle = '#2c6b52';
    ctx.beginPath(); ctx.arc(cx, cy, R * ms, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = 'rgba(160,230,255,0.35)'; ctx.lineWidth = 1.5; ctx.setLineDash([4, 6]);
    ctx.beginPath(); ctx.arc(cx, cy, (R + PLANET.atmHeight) * ms, 0, Math.PI * 2); ctx.stroke();
    ctx.setLineDash([]);

    // base
    ctx.fillStyle = '#ff7a45';
    ctx.beginPath(); ctx.arc(cx, cy - R * ms, 3, 0, Math.PI * 2); ctx.fill();

    // rastro
    if (trail.length > 4) {
      ctx.strokeStyle = 'rgba(255,255,255,0.22)'; ctx.lineWidth = 1.5;
      ctx.beginPath();
      for (var i = 0; i < trail.length; i += 2) {
        var tx = cx + trail[i] * ms, ty = cy - trail[i + 1] * ms;
        if (i === 0) ctx.moveTo(tx, ty); else ctx.lineTo(tx, ty);
      }
      ctx.stroke();
    }

    // órbita prevista
    if (s.state === 'flying' && o.e < 5) {
      var nu0 = 0, nu1 = Math.PI * 2;
      if (o.e >= 1) { nu0 = -Math.acos(-1 / o.e) + 0.05; nu1 = -nu0; }
      else { nu0 = -Math.PI; nu1 = Math.PI; }
      var steps = 220, px = 0, py = 0, pin = false;
      ctx.lineWidth = 2;
      for (var k = 0; k <= steps; k++) {
        var nu = nu0 + (nu1 - nu0) * k / steps;
        var rr = o.p / (1 + o.e * Math.cos(nu));
        if (!isFinite(rr) || rr <= 0) continue;
        var ang = nu + o.w;
        var qx = cx + rr * ms * Math.cos(ang), qy = cy - rr * ms * Math.sin(ang);
        var inside = rr < R;
        if (k > 0) {
          ctx.strokeStyle = (inside || pin) ? '#ff5d6c' : '#6fd3ff';
          ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(qx, qy); ctx.stroke();
        }
        px = qx; py = qy; pin = inside;
      }
      // pontos mais alto e mais baixo
      var apx = cx + o.ra * ms * Math.cos(o.w + Math.PI), apy = cy - o.ra * ms * Math.sin(o.w + Math.PI);
      var pex = cx + o.rp * ms * Math.cos(o.w), pey = cy - o.rp * ms * Math.sin(o.w);
      ctx.font = '11px ui-monospace, monospace'; ctx.fillStyle = '#dfe8ff';
      if (isFinite(o.ra)) { ctx.beginPath(); ctx.arc(apx, apy, 3.5, 0, Math.PI * 2); ctx.fill(); ctx.fillText('AP', apx + 7, apy + 4); }
      if (o.rp > R) { ctx.beginPath(); ctx.arc(pex, pey, 3.5, 0, Math.PI * 2); ctx.fill(); ctx.fillText('PE', pex + 7, pey + 4); }
    }

    // foguete
    if (s.state !== 'crashed') {
      var rx = cx + s.x * ms, ry = cy - s.y * ms;
      ctx.save(); ctx.translate(rx, ry); ctx.rotate(Math.PI / 2 - s.th);
      ctx.fillStyle = '#ffffff'; tri(ctx, 0, -9, 5, 6, -5, 6);
      ctx.restore();
    }
    for (var d = 0; d < s.debris.length; d++) {
      ctx.fillStyle = COL.mini;
      ctx.fillRect(cx + s.debris[d].x * ms - 1.5, cy - s.debris[d].y * ms - 1.5, 3, 3);
    }
  }

  // ---------- HUD ----------
  var PHASE_TXT = {
    SUBIDA: 'Piloto: subindo', INERCIA: 'Piloto: coasting até o topo', CIRCULAR: 'Piloto: circularizando',
    ORBITA: 'Em órbita ✓', FALHA: 'Piloto: sem combustível'
  };
  var NOTE_TXT = { CORRIGINDO: 'MINIS CORRIGINDO', IMPULSO: 'MINIS EM IMPULSO', FREANDO: 'MINIS FREANDO' };
  var hudT = 0;

  function updateHud(now) {
    var s = sim;
    if (now - hudT < 100) return;
    hudT = now;
    $('hAlt').textContent = fmtDist(s.alt);
    $('hVel').textContent = Math.round(s.speed) + ' m/s';
    $('hAp').textContent = s.state === 'flying' ? fmtDist(s.orb.apAlt) : '—';
    $('hPe').textContent = s.state === 'flying' ? fmtDist(s.orb.peAlt) : '—';
    $('hFuel').textContent = Math.round(s.fuel / s.rocket.fuelMax * 100) + '%';
    var tot = 0, n = 0, bs = s.rocket.boosters;
    for (var i = 0; i < bs.length; i++) if (bs[i].alive) { tot += bs[i].fuel / PARTS.mini.fuel; n++; }
    $('hMini').textContent = bs.length ? (n ? Math.round(tot / n * 100) + '%' : 'soltos') : '—';

    var st;
    if (s.state === 'crashed') st = 'Destruído';
    else if (s.auto) st = PHASE_TXT[s.phase] || 'Piloto automático';
    else if (s.state === 'landed') st = s.t < 1 ? 'Na base' : 'Pousado';
    else if (s.orb.peAlt >= AUTO.peTarget - 5000) st = 'Em órbita ✓';
    else st = s.sas ? 'Voo manual · estabilizado' : 'Voo manual';
    $('stState').textContent = st;
    $('stNote').textContent = NOTE_TXT[s.note] || '';

    $('thrFill').style.height = Math.round((s.auto ? s.throttle : thr) * 100) + '%';
    syncButtons();
  }

  function syncButtons() {
    var s = sim, any = false, i;
    for (i = 0; i < s.rocket.boosters.length; i++) if (s.rocket.boosters[i].alive) any = true;
    $('btnAuto').classList.toggle('on', s.auto);
    $('btnSas').classList.toggle('on', s.sas && !s.auto);
    $('btnMap').classList.toggle('on', view.map);
    $('btnDrop').style.opacity = any ? 1 : 0.4;
    var eff = effectiveWarp();
    $('btnWarp').textContent = '×' + view.warp;
    $('btnWarp').classList.toggle('on', view.warp > 1 && eff === view.warp);
    $('btnWarp').classList.toggle('warn', view.warp > 1 && eff < view.warp);
  }

  // ---------- toques ----------
  function manualOverride() { if (sim.auto) sim.setAuto(false); }

  function hold(btn, fn) {
    btn.addEventListener('pointerdown', function (e) {
      e.preventDefault();
      try { btn.setPointerCapture(e.pointerId); } catch (x) {}
      btn.classList.add('held'); fn(true);
    });
    var up = function () { btn.classList.remove('held'); fn(false); };
    btn.addEventListener('pointerup', up);
    btn.addEventListener('pointercancel', up);
  }
  hold($('btnLeft'), function (v) { held.left = v; if (v) manualOverride(); });
  hold($('btnRight'), function (v) { held.right = v; if (v) manualOverride(); });

  var thrEl = $('thr'), thrDrag = false;
  function setThr(e) {
    var r = thrEl.getBoundingClientRect();
    var v = clamp(1 - (e.clientY - r.top) / r.height, 0, 1);
    thr = v < 0.04 ? 0 : (v > 0.96 ? 1 : v);
  }
  thrEl.addEventListener('pointerdown', function (e) {
    e.preventDefault(); thrDrag = true;
    try { thrEl.setPointerCapture(e.pointerId); } catch (x) {}
    manualOverride(); setThr(e);
  });
  thrEl.addEventListener('pointermove', function (e) { if (thrDrag) setThr(e); });
  var thrUp = function () { thrDrag = false; };
  thrEl.addEventListener('pointerup', thrUp);
  thrEl.addEventListener('pointercancel', thrUp);
  $('thrMax').addEventListener('click', function () { manualOverride(); thr = 1; });
  $('thrZero').addEventListener('click', function () { manualOverride(); thr = 0; });

  $('btnAuto').addEventListener('click', function () {
    if (sim.state === 'crashed') return;
    sim.setAuto(!sim.auto);
    if (sim.auto) sim.setSas(false);
    syncButtons();
  });
  $('btnSas').addEventListener('click', function () {
    if (sim.auto) sim.setAuto(false);
    sim.setSas(!sim.sas);
    syncButtons();
  });
  $('btnDrop').addEventListener('click', function () { sim.dropMinis(); syncButtons(); });
  $('btnMap').addEventListener('click', function () { view.map = !view.map; syncButtons(); });
  $('btnWarp').addEventListener('click', function () {
    var i = WARPS.indexOf(view.warp);
    view.warp = WARPS[(i + 1) % WARPS.length];
    syncButtons();
  });
  $('btnZoomIn').addEventListener('click', function () {
    if (view.map) view.mapZoom = clamp(view.mapZoom * 1.4, 0.3, 20);
    else view.zoom = clamp(view.zoom * 1.5, 0.0005, 40);
  });
  $('btnZoomOut').addEventListener('click', function () {
    if (view.map) view.mapZoom = clamp(view.mapZoom / 1.4, 0.3, 20);
    else view.zoom = clamp(view.zoom / 1.5, 0.0005, 40);
  });
  $('btnMenu').addEventListener('click', toHangar);
  $('btnAgain').addEventListener('click', toHangar);
  $('btnLaunch').addEventListener('click', startFlight);

  // teclado (para testar no computador)
  window.addEventListener('keydown', function (e) {
    if (screen !== 'flight') return;
    if (e.key === 'ArrowLeft') { held.left = true; manualOverride(); }
    else if (e.key === 'ArrowRight') { held.right = true; manualOverride(); }
    else if (e.key === 'z') { manualOverride(); thr = 1; }
    else if (e.key === 'x') { manualOverride(); thr = 0; }
    else if (e.key === 'a') $('btnAuto').click();
    else if (e.key === 'm') $('btnMap').click();
  });
  window.addEventListener('keyup', function (e) {
    if (e.key === 'ArrowLeft') held.left = false;
    else if (e.key === 'ArrowRight') held.right = false;
  });

  // botão "voltar" do Android
  window.onBack = function () {
    if (screen === 'flight') { toHangar(); return 'ok'; }
    return 'exit';
  };

  // para testes automatizados
  window.__game = { get sim() { return sim; }, startFlight: startFlight };

  // ---------- laço principal ----------
  var last = performance.now();
  function frame(now) {
    var rdt = Math.min((now - last) / 1000, 0.05);
    last = now;
    if (screen === 'flight') {
      stepPhysics(rdt);
      if (view.map) drawMap(); else drawFlight();
      updateHud(now);
    } else {
      drawHangar();
    }
    requestAnimationFrame(frame);
  }
  renderHangar();
  requestAnimationFrame(frame);
})();
