// ============================================================
//  CÉREBROS AUTOMÁTICOS
//  1) autoGuidance: piloto automático da cápsula (sobe até a órbita)
//  2) boosterBrain: os mini foguetes decidem sozinhos quando
//     ligar e para que lado empurrar
//  Mexa nos números daqui para mudar o comportamento.
// ============================================================

var AUTO = {
  apTarget: 80000,  // altura do ponto mais alto da órbita (m)
  peTarget: 72000   // altura mínima para considerar "em órbita" (m)
};

var BRAIN = {
  tiltLimit: 0.25,        // erro de ângulo (rad) a partir do qual os minis corrigem o giro
  assistAlt: 30000,       // até essa altura os minis ajudam na subida
  reserve: 0.4,           // fração de combustível guardada para correção e pouso
  landSeconds: 6          // segundos para o chão em que os minis freiam a queda
};

// ---------- piloto automático ----------
function autoGuidance(s) {
  var o = s.orb, eng = s.rocket.eng, gm = PLANET.gm;
  s.autoThr = 0;
  var prograde = s.speed > 2 ? Math.atan2(s.vy, s.vx) : s.upAng;

  // direção a partir do "para cima" (0) em direção ao "leste" (PI/2)
  function dirAngle(pitch) {
    var dx = s.ux * Math.cos(pitch) + s.ex * Math.sin(pitch);
    var dy = s.uy * Math.cos(pitch) + s.ey * Math.sin(pitch);
    return Math.atan2(dy, dx);
  }

  if (s.fuel <= 0 && s.phase !== 'ORBITA') s.phase = 'FALHA';

  if (s.phase === 'SUBIDA') {
    // curva suave: vertical no começo, deitando conforme sobe
    var pitch = (Math.PI / 2) * Math.pow(clamp(s.alt / 70000, 0, 1), 0.6);
    s.autoTarget = dirAngle(pitch);
    s.autoThr = 1;
    // passou da parte baixa da atmosfera: os minis já ajudaram, soltam para aliviar o peso
    if (s.alt > BRAIN.assistAlt) s.dropMinis();
    if (o.apAlt >= AUTO.apTarget) s.phase = 'INERCIA';
  } else if (s.phase === 'INERCIA') {
    s.autoTarget = prograde;
    // se o ar ainda está roubando altura, dá uma ajudinha no motor
    if (s.alt < PLANET.atmHeight && o.apAlt < AUTO.apTarget - 300) s.autoThr = 0.4;
    // calcula quando começar a queima de circularização
    var aIn = gm / (s.r * s.r) - s.vt * s.vt / s.r;
    var tApo = s.vr > 0 ? s.vr / Math.max(aIn, 0.05) : 0;
    var vCirc = Math.sqrt(gm / Math.max(o.ra, PLANET.radius));
    var vApo = Math.abs(o.h) / Math.max(o.ra, PLANET.radius);
    var dv = Math.max(vCirc - vApo, 0);
    var ve = eng.isp * G0;
    var tb = ve * s.mass() * (1 - Math.exp(-dv / ve)) / eng.thrust;
    if (s.vr <= 0 || tApo <= tb / 2) s.phase = 'CIRCULAR';
  } else if (s.phase === 'CIRCULAR') {
    // empurra na horizontal; se estiver afundando, levanta um pouco o nariz
    var ph = clamp(-0.004 * s.vr, -0.35, 0.35);
    s.autoTarget = dirAngle(Math.PI / 2 - ph);
    s.autoThr = (o.peAlt > AUTO.peTarget - 4000) ? 0.35 : 1;
    if (o.peAlt >= AUTO.peTarget) s.phase = 'ORBITA';
  } else if (s.phase === 'ORBITA') {
    s.autoTarget = prograde;
    s.autoThr = 0;
  } else { // FALHA
    s.autoTarget = prograde;
    s.autoThr = 0;
  }
}

// ---------- mini foguetes automáticos ----------
function boosterBrain(s, hasTarget, target, thr) {
  var bs = s.rocket.boosters, mn = PARTS.mini, i, b;
  var alive = [];
  for (i = 0; i < bs.length; i++) {
    b = bs[i]; b.firing = false;
    if (b.alive && b.fuel > 0) alive.push(b);
  }
  s.note = '';
  if (!alive.length || s.state === 'crashed') return;

  // 1) Foguete torto em relação ao rumo desejado: liga o lado que gira de volta
  if (hasTarget && s.state === 'flying') {
    var err = angDiff(target, s.th);
    if (Math.abs(err) > BRAIN.tiltLimit) {
      var side = err > 0 ? 1 : -1;
      for (i = 0; i < alive.length; i++) if (Math.sign(alive[i].cx) === side) alive[i].firing = true;
      s.note = 'CORRIGINDO';
      return;
    }
  }

  // 2) Queda rápida perto do chão com o nariz para cima: freiam com tudo
  if (s.state === 'flying' && s.vr < -25 && s.alt < Math.max(300, -s.vr * BRAIN.landSeconds)) {
    var tilt = Math.abs(angDiff(s.th, s.upAng));
    if (tilt < 0.6) {
      for (i = 0; i < alive.length; i++) alive[i].firing = true;
      s.note = 'FREANDO';
      return;
    }
  }

  // 3) Subida: ajudam o motor principal na parte baixa, gastando só até a reserva
  if (thr > 0.05 && s.alt < BRAIN.assistAlt && s.vr > -5) {
    var used = false;
    for (i = 0; i < alive.length; i++) {
      if (alive[i].fuel / mn.fuel > BRAIN.reserve) { alive[i].firing = true; used = true; }
    }
    if (used) s.note = 'IMPULSO';
  }
}
