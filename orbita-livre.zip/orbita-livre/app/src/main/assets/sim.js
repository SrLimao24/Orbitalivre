// ============================================================
//  FÍSICA DO JOGO (não mexe em tela, só em números)
// ============================================================

function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }
function wrapAng(a) {
  while (a > Math.PI) a -= 2 * Math.PI;
  while (a < -Math.PI) a += 2 * Math.PI;
  return a;
}
function angDiff(to, from) { return wrapAng(to - from); }
function byId(list, id) {
  for (var i = 0; i < list.length; i++) if (list[i].id === id) return list[i];
  return list[0];
}

// Monta o foguete a partir da configuração escolhida no hangar
function buildRocket(cfg) {
  var tank = byId(PARTS.tanks, cfg.tank);
  var eng = byId(PARTS.engines, cfg.engine);
  var n = clamp(cfg.tanks | 0, 1, 4);
  var pairs = clamp(cfg.minis | 0, 0, 3);
  var rk = { cfg: cfg, tank: tank, eng: eng, n: n, pairs: pairs, boosters: [] };
  rk.dry = PARTS.capsule.dry + n * tank.dry + eng.dry;
  rk.fuelMax = n * tank.fuel;
  rk.H = PARTS.capsule.h + n * tank.h + eng.h;
  rk.W = Math.max(PARTS.capsule.w, tank.w, eng.w);
  var mn = PARTS.mini;
  for (var p = 0; p < pairs; p++) {
    for (var s = -1; s <= 1; s += 2) {
      rk.boosters.push({
        side: s, pair: p,
        cx: s * (rk.W / 2 + mn.w / 2 + 0.7 + p * (mn.w + 0.1)), // distância do centro (braço do giro)
        fuel: mn.fuel, alive: true, firing: false
      });
    }
  }
  return rk;
}

// Elementos da órbita a partir de posição e velocidade
function orbitOf(x, y, vx, vy) {
  var gm = PLANET.gm, r = Math.sqrt(x * x + y * y), v2 = vx * vx + vy * vy;
  var h = x * vy - y * vx;
  var rv = x * vx + y * vy;
  var ex = ((v2 - gm / r) * x - rv * vx) / gm;
  var ey = ((v2 - gm / r) * y - rv * vy) / gm;
  var e = Math.sqrt(ex * ex + ey * ey);
  var eps = v2 / 2 - gm / r;
  var o = { e: e, h: h, w: Math.atan2(ey, ex), p: h * h / gm };
  if (eps < 0) {
    o.a = -gm / (2 * eps);
    o.rp = o.a * (1 - e);
    o.ra = o.a * (1 + e);
    o.period = 2 * Math.PI * Math.sqrt(o.a * o.a * o.a / gm);
  } else {
    o.a = Infinity; o.rp = o.p / (1 + e); o.ra = Infinity; o.period = Infinity;
  }
  o.apAlt = o.ra - PLANET.radius;
  o.peAlt = o.rp - PLANET.radius;
  return o;
}

function Sim(cfg) {
  this.cfg = cfg;
  this.rocket = buildRocket(cfg);
  this.reset();
}

Sim.prototype.reset = function () {
  var rk = this.rocket;
  this.x = 0; this.y = PLANET.radius + rk.H / 2;
  this.vx = 0; this.vy = 0;
  this.th = Math.PI / 2;   // ângulo do nariz (0 = direita, 90° = cima)
  this.w = 0;              // velocidade de giro
  this.fuel = rk.fuelMax;
  this.thrIn = 0;          // acelerador pedido pelo jogador
  this.rotIn = 0;          // giro pedido pelo jogador (+1 anti-horário, -1 horário)
  this.throttle = 0;       // acelerador efetivo (o que realmente está valendo)
  this.state = 'landed';   // landed | flying | crashed
  this.t = 0;
  this.auto = false; this.sas = false;
  this.sasTarget = this.th; this.autoTarget = this.th; this.autoThr = 0;
  this.phase = '';
  this.debris = [];
  this.boom = null;
  this.mainThrust = 0;
  this.note = '';
  for (var i = 0; i < rk.boosters.length; i++) {
    var b = rk.boosters[i];
    b.fuel = PARTS.mini.fuel; b.alive = true; b.firing = false;
  }
  this.derive();
};

Sim.prototype.mass = function () {
  var m = this.rocket.dry + this.fuel, bs = this.rocket.boosters;
  for (var i = 0; i < bs.length; i++) if (bs[i].alive) m += PARTS.mini.dry + bs[i].fuel;
  return m;
};

Sim.prototype.derive = function () {
  var P = PLANET, rk = this.rocket;
  var r = Math.sqrt(this.x * this.x + this.y * this.y);
  this.r = r;
  this.ux = this.x / r; this.uy = this.y / r;      // "para cima" neste ponto
  this.ex = this.uy; this.ey = -this.ux;           // "leste" (sentido horário)
  this.vr = this.vx * this.ux + this.vy * this.uy; // velocidade vertical
  this.vt = this.vx * this.ex + this.vy * this.ey; // velocidade horizontal
  this.speed = Math.sqrt(this.vx * this.vx + this.vy * this.vy);
  this.alt = Math.max(0, r - P.radius - rk.H / 2);
  this.upAng = Math.atan2(this.uy, this.ux);
  this.orb = orbitOf(this.x, this.y, this.vx, this.vy);
};

Sim.prototype.setAuto = function (on) {
  this.auto = !!on;
  if (on) {
    this.derive();
    var o = this.orb;
    if (o.peAlt >= AUTO.peTarget) this.phase = 'ORBITA';
    else if (this.state === 'landed' || this.alt < PLANET.atmHeight || o.apAlt < AUTO.apTarget) this.phase = 'SUBIDA';
    else this.phase = 'INERCIA';
  } else {
    this.phase = '';
    this.sasTarget = this.th;
  }
};

Sim.prototype.setSas = function (on) {
  this.sas = !!on;
  this.sasTarget = this.th;
};

Sim.prototype.detach = function (b) {
  if (!b.alive) return;
  b.alive = false; b.firing = false;
  var rx = Math.sin(this.th), ry = -Math.cos(this.th); // "direita" do foguete
  this.debris.push({
    x: this.x + rx * b.cx, y: this.y + ry * b.cx,
    vx: this.vx + rx * Math.sign(b.cx) * 2.5, vy: this.vy + ry * Math.sign(b.cx) * 2.5,
    th: this.th, w: Math.sign(b.cx) * 0.4, t: 0
  });
};

Sim.prototype.dropMinis = function () {
  var bs = this.rocket.boosters;
  for (var i = 0; i < bs.length; i++) this.detach(bs[i]);
};

Sim.prototype.crash = function () {
  this.state = 'crashed';
  this.boom = { x: this.x, y: this.y, t: 0 };
  this.throttle = 0; this.mainThrust = 0; this.note = '';
  var bs = this.rocket.boosters;
  for (var i = 0; i < bs.length; i++) bs[i].firing = false;
};

Sim.prototype.updateDebris = function (dt) {
  var gm = PLANET.gm;
  for (var i = this.debris.length - 1; i >= 0; i--) {
    var d = this.debris[i];
    var r = Math.sqrt(d.x * d.x + d.y * d.y);
    var g = gm / (r * r);
    d.vx -= g * d.x / r * dt; d.vy -= g * d.y / r * dt;
    d.x += d.vx * dt; d.y += d.vy * dt;
    d.th += d.w * dt; d.t += dt;
    if (r < PLANET.radius || d.t > 60) this.debris.splice(i, 1);
  }
  if (this.boom) this.boom.t += dt;
};

// Um passo de física (dt em segundos). Chame várias vezes por quadro.
Sim.prototype.step = function (dt) {
  if (this.state === 'crashed') { this.updateDebris(dt); return; }
  var P = PLANET, rk = this.rocket, eng = rk.eng, mn = PARTS.mini;
  this.derive();

  // --- piloto automático e estabilizador ---
  var thr = clamp(this.thrIn, 0, 1);
  var hasTarget = false, target = 0;
  if (this.auto) {
    autoGuidance(this);
    thr = this.autoThr; hasTarget = true; target = this.autoTarget;
  } else if (this.sas) {
    hasTarget = true; target = this.sasTarget;
  }

  var alphaMax = PARTS.rw.alpha, cmd = 0;
  if (this.state === 'landed') {
    this.w = 0;
  } else if (!this.auto && this.rotIn !== 0) {
    cmd = this.rotIn * alphaMax;
    this.sasTarget = this.th;
  } else if (hasTarget) {
    var err = angDiff(target, this.th);
    cmd = clamp(2.2 * err - 2.9 * this.w, -alphaMax, alphaMax);
  }

  // --- mini foguetes decidem sozinhos ---
  boosterBrain(this, hasTarget, target, thr);

  // --- forças ---
  var m = this.mass();
  var nx = Math.cos(this.th), ny = Math.sin(this.th);
  var rho = this.alt < P.atmHeight ? P.rho0 * Math.exp(-this.alt / P.scaleHeight) : 0;
  var pfrac = rho / P.rho0;
  var fx = 0, fy = 0, torque = 0;

  this.mainThrust = 0;
  if (this.fuel > 0 && thr > 0) {
    var flow = thr * eng.thrust / (eng.isp * G0);
    var burn = Math.min(flow * dt, this.fuel);
    var isp = eng.isp * (0.8 + 0.2 * (1 - pfrac)); // no ar o motor rende menos
    var F = burn / dt * isp * G0;
    this.fuel -= burn;
    this.mainThrust = F;
    fx += F * nx; fy += F * ny;
  }
  this.throttle = this.fuel > 0 ? thr : 0;

  var toDetach = [];
  for (var i = 0; i < rk.boosters.length; i++) {
    var b = rk.boosters[i];
    if (b.alive && b.firing && b.fuel > 0) {
      var bb = Math.min(mn.thrust / (mn.isp * G0) * dt, b.fuel);
      var Fb = bb / dt * mn.isp * G0;
      b.fuel -= bb;
      fx += Fb * nx; fy += Fb * ny;
      torque += Math.sign(b.cx) * Math.abs(b.cx) * Fb;
      if (b.fuel <= 1e-6) toDetach.push(b);
    } else {
      b.firing = false;
    }
  }
  for (i = 0; i < toDetach.length; i++) this.detach(toDetach[i]);

  // arrasto do ar
  var aero = 0, damp = 0;
  var sp = this.speed;
  if (rho > 0 && sp > 0.5) {
    var q = 0.5 * rho * sp * sp;
    var vhx = this.vx / sp, vhy = this.vy / sp;
    var cosa = nx * vhx + ny * vhy;
    var sin2 = 1 - cosa * cosa;
    var Af = Math.PI * rk.W * rk.W / 4, As = rk.H * rk.W * 0.8;
    var CdA = 0.3 * Af * cosa * cosa + 1.0 * As * sin2;
    fx -= q * CdA * vhx; fy -= q * CdA * vhy;
    var da = angDiff(Math.atan2(this.vy, this.vx), this.th);
    aero = 1.0e-5 * q * Math.sin(da);   // o ar tenta alinhar o nariz com o vento
    damp = -1.0e-5 * q * this.w;        // e segura o giro
  }

  var I = Math.max(m * rk.H * rk.H / 12, 1000);
  var alpha = cmd + torque / I + aero + damp;

  var g = P.gm / (this.r * this.r);
  var ax = fx / m - g * this.ux;
  var ay = fy / m - g * this.uy;

  // --- integração ---
  if (this.state !== 'landed') {
    this.w += alpha * dt;
    this.th = wrapAng(this.th + this.w * dt);
  }
  this.vx += ax * dt; this.vy += ay * dt;
  this.x += this.vx * dt; this.y += this.vy * dt;
  this.t += dt;

  // --- chão ---
  var r2 = Math.sqrt(this.x * this.x + this.y * this.y);
  var floor = P.radius + rk.H / 2;
  if (r2 <= floor) {
    var ux = this.x / r2, uy = this.y / r2;
    var vr = this.vx * ux + this.vy * uy;
    if (vr <= 0) {
      var spd = Math.sqrt(this.vx * this.vx + this.vy * this.vy);
      var tilt = Math.abs(angDiff(this.th, Math.atan2(uy, ux)));
      if (this.state === 'flying' && (spd > 14 || tilt > 0.7)) {
        this.crash();
        this.updateDebris(dt);
        return;
      }
      this.x = ux * floor; this.y = uy * floor;
      this.vx = 0; this.vy = 0; this.w = 0;
      if (tilt < 0.7) this.th = Math.atan2(uy, ux);
      this.state = 'landed';
    }
  } else if (this.state === 'landed' && r2 > floor + 0.5) {
    this.state = 'flying';
  }

  this.updateDebris(dt);
};

if (typeof module !== 'undefined') module.exports = { Sim: Sim };
