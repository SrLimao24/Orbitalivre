// ============================================================
//  PEÇAS E NÚMEROS DO JOGO
//  Mexa aqui para criar peças novas ou equilibrar o jogo.
//  Unidades: metros, quilos, newtons, segundos.
// ============================================================

var G0 = 9.8; // gravidade padrão (usada na fórmula do empuxo)

var PLANET = {
  name: 'Terra Nova',
  radius: 600000,    // raio em metros
  g0: 9.8,           // gravidade na superfície
  atmHeight: 70000,  // altura onde acaba o ar
  rho0: 1.2,         // densidade do ar ao nível do mar
  scaleHeight: 5600  // quanto mais alto, mais fino fica o ar
};
PLANET.gm = PLANET.g0 * PLANET.radius * PLANET.radius;

var PARTS = {
  capsule: { name: 'Cápsula', dry: 1000, h: 3.0, w: 2.4 },

  tanks: [
    { id: 'p', name: 'Tanque pequeno', dry: 400,  fuel: 2500,  h: 2.5, w: 2.4 },
    { id: 'm', name: 'Tanque médio',   dry: 900,  fuel: 6000,  h: 4.0, w: 3.0 },
    { id: 'g', name: 'Tanque grande',  dry: 2000, fuel: 14000, h: 7.0, w: 3.6 }
  ],

  // thrust = empuxo no vácuo (N), isp = eficiência do motor (s)
  engines: [
    { id: 'f', name: 'Faísca', thrust: 70e3,  isp: 300, dry: 500,  h: 1.6, w: 1.4 },
    { id: 'c', name: 'Cometa', thrust: 240e3, isp: 320, dry: 1200, h: 2.0, w: 2.0 },
    { id: 't', name: 'Titã',   thrust: 650e3, isp: 340, dry: 3000, h: 2.6, w: 2.8 }
  ],

  // Mini foguetes automáticos (cada "par" = um de cada lado)
  mini: { name: 'Mini foguete', thrust: 45e3, isp: 250, dry: 150, fuel: 900, h: 3.2, w: 0.8 },

  // Roda de reação da cápsula: quanto o foguete consegue girar sozinho (rad/s²)
  rw: { alpha: 0.9 }
};

// Foguete que já vem montado
var DEFAULT_CONFIG = { tank: 'm', tanks: 2, engine: 'c', minis: 1 };
