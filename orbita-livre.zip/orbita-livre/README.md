# Órbita Livre

Simulador de foguete 2D para celular. Você monta o foguete no hangar, lança e tenta chegar à órbita.
O diferencial: **mini foguetes automáticos** que decidem sozinhos quando ligar e para onde empurrar.

O jogo é um app Android que abre uma página web (WebView). Todo o jogo está em código simples,
na pasta `app/src/main/assets/`. Para mudar o jogo, edite esses arquivos.

## Onde mexer

| Arquivo | O que tem |
|---|---|
| `parts.js` | Peças (tanques, motores, mini foguete), planeta, números de equilíbrio |
| `sim.js` | Física: gravidade, ar, empuxo, pouso e batida |
| `autopilot.js` | **Cérebro dos mini foguetes** (`boosterBrain`) e piloto automático da cápsula (`autoGuidance`) |
| `ui.js` | Tela, botões, câmera, desenho do foguete |
| `style.css` | Cores e tamanho dos botões |

Exemplos rápidos:
- Mini foguete mais forte: em `parts.js`, aumente `thrust` de `mini`.
- Mini foguetes que corrigem o giro mais cedo: em `autopilot.js`, diminua `BRAIN.tiltLimit`.
- Outra altura de órbita: em `autopilot.js`, mude `AUTO.apTarget`.

## Gerar o APK (sem computador)

1. Coloque estes arquivos num repositório do GitHub (branch `main`).
2. Abra o repositório → aba **Actions** → **Gerar APK**. Ele roda sozinho a cada alteração
   (ou toque em **Run workflow**). Leva uns 3 a 5 minutos.
3. Quando terminar, abra a execução e baixe **OrbitaLivre-apk** (arquivo zip com o `app-debug.apk`).
4. Extraia o zip, abra o APK no celular e permita instalar de fontes desconhecidas.

## Gerar o APK no computador (opcional)

Com Android Studio: abra a pasta, espere sincronizar e use **Build → Build APK(s)**.

## Controles

- **Acelerador** (barra à esquerda): arraste para cima e para baixo. MAX e 0 são atalhos.
- **◀ ▶**: girar o foguete.
- **AUTO**: piloto automático sobe até a órbita sozinho. Tocar em qualquer controle manual desliga.
- **ESTAB**: segura o rumo atual.
- **SOLTAR**: solta os mini foguetes. No AUTO eles se soltam sozinhos acima de 30 km.
- **MAPA**: vê a órbita. **×1**: acelera o tempo (só fora do ar e sem motor ligado).
- Para pousar: chegue com menos de 14 m/s e o nariz para cima. Se sobrar combustível nos mini
  foguetes, eles freiam a queda sozinhos perto do chão.
